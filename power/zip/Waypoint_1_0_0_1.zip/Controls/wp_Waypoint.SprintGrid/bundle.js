/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./SprintGrid/Grid.tsx"
/*!*****************************!*\
  !*** ./SprintGrid/Grid.tsx ***!
  \*****************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   Grid: () => (/* binding */ Grid)\n/* harmony export */ });\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);\nfunction _slicedToArray(r, e) { return _arrayWithHoles(r) || _iterableToArrayLimit(r, e) || _unsupportedIterableToArray(r, e) || _nonIterableRest(); }\nfunction _nonIterableRest() { throw new TypeError(\"Invalid attempt to destructure non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.\"); }\nfunction _unsupportedIterableToArray(r, a) { if (r) { if (\"string\" == typeof r) return _arrayLikeToArray(r, a); var t = {}.toString.call(r).slice(8, -1); return \"Object\" === t && r.constructor && (t = r.constructor.name), \"Map\" === t || \"Set\" === t ? Array.from(r) : \"Arguments\" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0; } }\nfunction _arrayLikeToArray(r, a) { (null == a || a > r.length) && (a = r.length); for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e]; return n; }\nfunction _iterableToArrayLimit(r, l) { var t = null == r ? null : \"undefined\" != typeof Symbol && r[Symbol.iterator] || r[\"@@iterator\"]; if (null != t) { var e, n, i, u, a = [], f = !0, o = !1; try { if (i = (t = t.call(r)).next, 0 === l) { if (Object(t) !== t) return; f = !1; } else for (; !(f = (e = i.call(t)).done) && (a.push(e.value), a.length !== l); f = !0); } catch (r) { o = !0, n = r; } finally { try { if (!f && null != t.return && (u = t.return(), Object(u) !== u)) return; } finally { if (o) throw n; } } return a; } }\nfunction _arrayWithHoles(r) { if (Array.isArray(r)) return r; }\n;\n/** The class the cell is drawn in: the kind, unless a work cell carries a status. */\nfunction cellClass(cell) {\n  var _a;\n  if (cell.kind === \"work\") {\n    if (cell.status === \"Late\") return \"wp-cell-blocked\";\n    if ((_a = cell.status) === null || _a === void 0 ? void 0 : _a.startsWith(\"At risk\")) return \"wp-cell-atrisk\";\n    return \"wp-cell-work\";\n  }\n  return \"wp-cell-\" + cell.kind;\n}\n/** The title tooltip, empty when the cell carries none. */\nfunction tipOf(cell) {\n  var _a;\n  return (_a = cell.tooltip) !== null && _a !== void 0 ? _a : \"\";\n}\n/** The status a work cell says in words as well as in colour. */\nfunction noteOf(cell) {\n  if (cell.kind !== \"work\" || !cell.status) return \"\";\n  if (cell.status === \"Late\" || cell.status.startsWith(\"At risk\")) return cell.status;\n  return \"\";\n}\nfunction initials(name) {\n  var parts = name.split(/\\s+/).filter(p => p.length > 0);\n  if (parts.length === 0) return \"\";\n  var first = parts[0].charAt(0);\n  var last = parts.length > 1 ? parts[parts.length - 1].charAt(0) : \"\";\n  return (first + last).toUpperCase();\n}\nvar Grid = props => {\n  var model = props.model,\n    theme = props.theme,\n    width = props.width,\n    height = props.height,\n    onSelect = props.onSelect;\n  var days = model.days;\n  // Every person row in order, so the caret can move between squads.\n  var rows = react__WEBPACK_IMPORTED_MODULE_0__.useMemo(() => model.groups.reduce((all, g) => all.concat(g.people), []), [model]);\n  // The first row of each squad, for PageUp and PageDown.\n  var starts = react__WEBPACK_IMPORTED_MODULE_0__.useMemo(() => {\n    var out = [];\n    var n = 0;\n    for (var g of model.groups) {\n      out.push(n);\n      n += g.people.length;\n    }\n    return out;\n  }, [model]);\n  // ---- the grid's own focus: one cell in the tab order, the arrows move it ----\n  var _React$useState = react__WEBPACK_IMPORTED_MODULE_0__.useState([0, 0]),\n    _React$useState2 = _slicedToArray(_React$useState, 2),\n    focus = _React$useState2[0],\n    setFocus = _React$useState2[1];\n  var buttons = react__WEBPACK_IMPORTED_MODULE_0__.useRef(new Map());\n  var at = (r, c) => r + \":\" + c;\n  var move = (r, c) => {\n    var rr = Math.max(0, Math.min(rows.length - 1, r));\n    var cc = Math.max(0, Math.min(days.length - 1, c));\n    setFocus([rr, cc]);\n    var node = buttons.current.get(at(rr, cc));\n    if (node) node.focus();\n  };\n  /** The first row of the squad before or after the one the caret sits in. */\n  var squadStep = (r, step) => {\n    var here = Math.max(0, starts.filter(s => s <= r).length - 1);\n    return starts[Math.max(0, Math.min(starts.length - 1, here + step))];\n  };\n  var _onKeyDown = (e, r, c, person) => {\n    if (e.key === \"Enter\" || e.key === \" \") {\n      e.preventDefault();\n      onSelect(person, days[c].date);\n      return;\n    }\n    var moves = {\n      ArrowRight: [r, c + 1],\n      ArrowLeft: [r, c - 1],\n      ArrowDown: [r + 1, c],\n      ArrowUp: [r - 1, c],\n      Home: [r, 0],\n      End: [r, days.length - 1],\n      PageDown: [squadStep(r, 1), c],\n      PageUp: [squadStep(r, -1), c]\n    };\n    var next = moves[e.key];\n    if (!next) return;\n    e.preventDefault();\n    move(next[0], next[1]);\n  };\n  var style = {\n    width: width,\n    height: height\n  };\n  var gridStyle = {\n    \"--wp-sg-days\": days.length\n  };\n  if (days.length === 0 || rows.length === 0) {\n    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n      className: \"wp-sg\",\n      \"data-theme\": theme,\n      style: style\n    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"p\", {\n      className: \"wp-sg__empty\"\n    }, \"No sprint to show.\"));\n  }\n  var r = -1;\n  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n    className: \"wp-sg\",\n    \"data-theme\": theme,\n    style: style\n  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n    className: \"wp-sg__grid\",\n    style: gridStyle\n  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n    className: \"wp-sg__row wp-sg__row--head\"\n  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n    className: \"wp-sg__name wp-sg__name--head\"\n  }, \"Person\"), days.map(day => (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n    className: \"wp-sg__day\",\n    key: day.date,\n    title: day.outside ? \"Outside the quarter\" : undefined\n  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"span\", {\n    className: \"wp-sg__day-date\"\n  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"span\", {\n    className: \"wp-sg__day-name\"\n  }, day.name), \" \", day.label), day.outside ? (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(react__WEBPACK_IMPORTED_MODULE_0__.Fragment, null, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"span\", {\n    className: \"wp-sg__day-dot\",\n    \"aria-hidden\": \"true\"\n  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"span\", {\n    className: \"wp-sg__sr\"\n  }, \"outside quarter\"))) : null)))), model.groups.map(group => (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n    key: group.name\n  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n    className: \"wp-sg__row wp-sg__row--group\"\n  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n    className: \"wp-sg__name\"\n  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"span\", {\n    className: \"wp-sg__group-name\"\n  }, group.name)), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n    className: \"wp-sg__group-meta\"\n  }, group.meta)), group.people.map(p => {\n    r += 1;\n    var row = r;\n    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n      className: \"wp-sg__row\",\n      key: p.name\n    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n      className: \"wp-sg__name\"\n    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"span\", {\n      className: \"wp-sg__avatar\",\n      \"aria-hidden\": \"true\"\n    }, initials(p.name)), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"span\", {\n      className: \"wp-sg__person\"\n    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"span\", {\n      className: \"wp-sg__person-name\"\n    }, p.name), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"span\", {\n      className: \"wp-sg__person-line\"\n    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"span\", {\n      className: \"wp-sg__person-role\"\n    }, p.role), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"span\", {\n      className: \"wp-sg__person-figs\"\n    }, p.meta ? \" · \" + p.meta : \"\")))), days.map((day, c) => {\n      var _a;\n      var cell = (_a = p.cells[c]) !== null && _a !== void 0 ? _a : {\n        kind: \"open\",\n        label: \"Open\"\n      };\n      var note = noteOf(cell);\n      var tip = tipOf(cell);\n      return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"button\", {\n        key: day.date,\n        type: \"button\",\n        ref: node => {\n          if (node) buttons.current.set(at(row, c), node);else buttons.current.delete(at(row, c));\n        },\n        className: \"wp-sg__cell \" + cellClass(cell),\n        \"aria-label\": p.name + \", \" + day.label + \": \" + (tip.length > 0 ? tip : cell.label),\n        title: tip.length > 0 ? tip : undefined,\n        tabIndex: focus[0] === row && focus[1] === c ? 0 : -1,\n        onKeyDown: e => _onKeyDown(e, row, c, p.name),\n        onFocus: () => setFocus([row, c]),\n        onClick: () => onSelect(p.name, day.date)\n      }, cell.kind === \"open\" ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"span\", {\n        className: \"wp-sg__cell-plus\",\n        \"aria-hidden\": \"true\"\n      }, \"+\") : null, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"span\", {\n        className: \"wp-sg__cell-text\"\n      }, cell.label, note ? \" · \" + note : \"\"));\n    }));\n  }))))));\n};\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./SprintGrid/Grid.tsx?\n}");

/***/ },

/***/ "./SprintGrid/index.ts"
/*!*****************************!*\
  !*** ./SprintGrid/index.ts ***!
  \*****************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   SprintGrid: () => (/* binding */ SprintGrid)\n/* harmony export */ });\n/* harmony import */ var _Grid__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Grid */ \"./SprintGrid/Grid.tsx\");\n/* harmony import */ var _model__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./model */ \"./SprintGrid/model.ts\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);\n\n\n\n/**\n * The sprint planning grid as a code component: people down, working days across, one typed cell\n * per person per day. A pure renderer. Everything it draws arrives on gridJson; the only thing it\n * sends back is the cell the reader picked.\n */\nclass SprintGrid {\n  constructor() {\n    this.model = {\n      days: [],\n      groups: []\n    };\n    this.raw = \"\";\n    this.selected = \"\";\n    this.onSelect = (person, date) => {\n      this.selected = JSON.stringify({\n        person: person,\n        date: date\n      });\n      this.notifyOutputChanged();\n    };\n    // Empty\n  }\n  init(context, notifyOutputChanged) {\n    this.notifyOutputChanged = notifyOutputChanged;\n    context.mode.trackContainerResize(true);\n  }\n  updateView(context) {\n    var _a, _b;\n    var raw = (_a = context.parameters.gridJson.raw) !== null && _a !== void 0 ? _a : \"\";\n    // The JSON is parsed once per change, not once per render.\n    if (raw !== this.raw) {\n      this.raw = raw;\n      this.model = (0,_model__WEBPACK_IMPORTED_MODULE_1__.parseGrid)(raw);\n    }\n    var theme = ((_b = context.parameters.theme.raw) !== null && _b !== void 0 ? _b : \"\").toLowerCase() === \"dark\" ? \"dark\" : \"light\";\n    var props = {\n      model: this.model,\n      theme: theme,\n      width: context.mode.allocatedWidth,\n      height: context.mode.allocatedHeight,\n      onSelect: this.onSelect\n    };\n    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2__.createElement(_Grid__WEBPACK_IMPORTED_MODULE_0__.Grid, props);\n  }\n  getOutputs() {\n    return {\n      selectedCellJson: this.selected\n    };\n  }\n  destroy() {\n    // Nothing to clean up: the framework unmounts the React tree itself.\n  }\n}\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./SprintGrid/index.ts?\n}");

/***/ },

/***/ "./SprintGrid/model.ts"
/*!*****************************!*\
  !*** ./SprintGrid/model.ts ***!
  \*****************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   parseGrid: () => (/* binding */ parseGrid)\n/* harmony export */ });\n/** The gridJson contract. The component is a pure renderer: everything it draws arrives here. */\nvar EMPTY = {\n  days: [],\n  groups: []\n};\n/** Reads gridJson. Anything malformed draws the empty grid rather than throwing at the host. */\nfunction parseGrid(raw) {\n  if (!raw) return EMPTY;\n  var parsed;\n  try {\n    parsed = JSON.parse(raw);\n  } catch (_a) {\n    return EMPTY;\n  }\n  var model = parsed;\n  if (!model || !Array.isArray(model.days) || !Array.isArray(model.groups)) return EMPTY;\n  return {\n    days: model.days,\n    groups: model.groups.map(g => ({\n      name: g.name,\n      meta: g.meta,\n      people: Array.isArray(g.people) ? g.people.map(p => ({\n        name: p.name,\n        role: p.role,\n        meta: p.meta,\n        cells: Array.isArray(p.cells) ? p.cells : []\n      })) : []\n    }))\n  };\n}\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./SprintGrid/model.ts?\n}");

/***/ },

/***/ "react"
/*!***************************!*\
  !*** external "Reactv16" ***!
  \***************************/
(module) {

module.exports = Reactv16;

/***/ }

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	const __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		const cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		const module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		if (!(moduleId in __webpack_modules__)) {
/******/ 			delete __webpack_module_cache__[moduleId];
/******/ 			const e = new Error("Cannot find module '" + moduleId + "'");
/******/ 			e.code = 'MODULE_NOT_FOUND';
/******/ 			throw e;
/******/ 		}
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = (module) => {
/******/ 		const getter = module && module.__esModule ?
/******/ 			() => (module['default']) :
/******/ 			() => (module);
/******/ 		__webpack_require__.d(getter, { a: getter });
/******/ 		return getter;
/******/ 	};
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	// define getter/value functions for harmony exports
/******/ 	__webpack_require__.d = (exports, definition) => {
/******/ 		for(var key in definition) {
/******/ 			if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 				Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 			}
/******/ 		}
/******/ 	};
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop));
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = (exports) => {
/******/ 		Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	let __webpack_exports__ = __webpack_require__("./SprintGrid/index.ts");
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('Waypoint.SprintGrid', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.SprintGrid);
} else {
	var Waypoint = Waypoint || {};
	Waypoint.SprintGrid = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.SprintGrid;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}